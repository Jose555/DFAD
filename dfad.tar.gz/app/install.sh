cp dfad /usr/bin
cp dfad /usr/local/bin
